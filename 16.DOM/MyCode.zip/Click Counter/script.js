var b = document.getElementById("box");
var clickcount = document.getElementById("count");
var count = 0;

b.addEventListener("click",function(){
    count++;
    clickcount.innerText = count;
    console.log(count);
})